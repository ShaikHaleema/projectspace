import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

const app = express();
const PORT = 3001;
const JWT_SECRET = 'your-secret-key';

// Middleware
app.use(cors());
app.use(express.json());

// Mock Database
let users = [];
let products = [
  {
    id: '1',
    name: 'iPhone 15 Pro Max',
    price: 134999,
    originalPrice: 159999,
    discount: 25000,
    rating: 4.6,
    reviews: 1250,
    image: 'https://images.pexels.com/photos/14525976/pexels-photo-14525976.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'electronics',
    description: 'The most advanced iPhone ever with titanium design, A17 Pro chip, and pro camera system.',
    specifications: {
      display: '6.7-inch Super Retina XDR',
      processor: 'A17 Pro chip',
      storage: '128GB',
      camera: '48MP Main camera',
      battery: 'Up to 29 hours video playback'
    },
    inStock: true
  },
  {
    id: '2',
    name: 'Samsung Galaxy S24 Ultra',
    price: 124999,
    originalPrice: 149999,
    discount: 25000,
    rating: 4.5,
    reviews: 890,
    image: 'https://images.pexels.com/photos/14525976/pexels-photo-14525976.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'electronics',
    description: 'Premium Android flagship with S Pen, advanced AI features, and exceptional camera performance.',
    specifications: {
      display: '6.8-inch Dynamic AMOLED 2X',
      processor: 'Snapdragon 8 Gen 3',
      storage: '256GB',
      camera: '200MP Main camera',
      battery: '5000mAh'
    },
    inStock: true
  },
  {
    id: '3',
    name: 'MacBook Air M3',
    price: 114900,
    originalPrice: 134900,
    discount: 20000,
    rating: 4.8,
    reviews: 560,
    image: 'https://images.pexels.com/photos/18105/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=400',
    category: 'electronics',
    description: 'Supercharged by the M3 chip, incredibly thin and light laptop with all-day battery life.',
    specifications: {
      display: '13.6-inch Liquid Retina',
      processor: 'Apple M3 chip',
      memory: '8GB unified memory',
      storage: '256GB SSD',
      battery: 'Up to 18 hours'
    },
    inStock: true
  },
  {
    id: '4',
    name: 'Nike Air Force 1',
    price: 7995,
    originalPrice: 8995,
    discount: 1000,
    rating: 4.4,
    reviews: 2100,
    image: 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'fashion',
    description: 'Classic white sneakers that never go out of style. Perfect for everyday wear.',
    specifications: {
      brand: 'Nike',
      material: 'Leather upper',
      sole: 'Rubber outsole',
      closure: 'Lace-up',
      origin: 'Vietnam'
    },
    inStock: true
  },
  {
    id: '5',
    name: 'Levi\'s 511 Slim Jeans',
    price: 2999,
    originalPrice: 3999,
    discount: 1000,
    rating: 4.3,
    reviews: 1520,
    image: 'https://images.pexels.com/photos/1598507/pexels-photo-1598507.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'fashion',
    description: 'Slim fit jeans with a modern look. Made with sustainable cotton.',
    specifications: {
      brand: 'Levi\'s',
      fit: 'Slim',
      material: '99% Cotton, 1% Elastane',
      rise: 'Mid Rise',
      closure: 'Button fly'
    },
    inStock: true
  },
  {
    id: '6',
    name: 'The Great Gatsby',
    price: 299,
    originalPrice: 399,
    discount: 100,
    rating: 4.7,
    reviews: 850,
    image: 'https://images.pexels.com/photos/159711/books-book-pages-read-literature-159711.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'books',
    description: 'Classic American novel by F. Scott Fitzgerald. A timeless tale of love and ambition.',
    specifications: {
      author: 'F. Scott Fitzgerald',
      publisher: 'Penguin Classics',
      pages: '180',
      language: 'English',
      format: 'Paperback'
    },
    inStock: true
  },
  {
    id: '7',
    name: 'Wooden Dining Table',
    price: 15999,
    originalPrice: 19999,
    discount: 4000,
    rating: 4.6,
    reviews: 320,
    image: 'https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'home',
    description: 'Solid wood dining table that seats up to 6 people. Perfect for family meals.',
    specifications: {
      material: 'Solid Oak Wood',
      dimensions: '180x90x75 cm',
      seatingCapacity: '6 people',
      finish: 'Natural wood finish',
      assembly: 'Required'
    },
    inStock: true
  },
  {
    id: '8',
    name: 'Yoga Mat Premium',
    price: 1299,
    originalPrice: 1799,
    discount: 500,
    rating: 4.5,
    reviews: 680,
    image: 'https://images.pexels.com/photos/3822864/pexels-photo-3822864.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'sports',
    description: 'High-quality yoga mat with excellent grip and cushioning for all types of yoga.',
    specifications: {
      material: 'TPE (Thermoplastic Elastomer)',
      thickness: '6mm',
      dimensions: '183x61 cm',
      weight: '1.2 kg',
      features: 'Non-slip, Eco-friendly'
    },
    inStock: true
  }
];

let carts = [];
let orders = [];

// Auth Middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
};

// Auth Routes
app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;

    // Check if user already exists
    const existingUser = users.find(user => user.email === email);
    if (existingUser) {
      return res.status(400).json({ error: 'User already exists' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create user
    const user = {
      id: Date.now().toString(),
      name,
      email,
      password: hashedPassword,
      createdAt: new Date().toISOString()
    };

    users.push(user);

    // Generate token
    const token = jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' });

    res.status(201).json({
      message: 'User created successfully',
      token,
      user: { id: user.id, name: user.name, email: user.email }
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find user
    const user = users.find(user => user.email === email);
    if (!user) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }

    // Check password
    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }

    // Generate token
    const token = jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' });

    res.json({
      message: 'Login successful',
      token,
      user: { id: user.id, name: user.name, email: user.email }
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/auth/profile', authenticateToken, (req, res) => {
  const user = users.find(user => user.id === req.user.userId);
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }

  res.json({
    user: { id: user.id, name: user.name, email: user.email }
  });
});

// Product Routes
app.get('/api/products', (req, res) => {
  res.json(products);
});

app.get('/api/products/:id', (req, res) => {
  const product = products.find(p => p.id === req.params.id);
  if (!product) {
    return res.status(404).json({ error: 'Product not found' });
  }
  res.json(product);
});

app.get('/api/products/search', (req, res) => {
  const query = req.query.q?.toLowerCase() || '';
  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(query) ||
    product.category.toLowerCase().includes(query) ||
    product.description.toLowerCase().includes(query)
  );
  res.json(filteredProducts);
});

app.get('/api/products/category/:category', (req, res) => {
  const category = req.params.category.toLowerCase();
  const filteredProducts = products.filter(product =>
    product.category.toLowerCase() === category
  );
  res.json(filteredProducts);
});

// Cart Routes
app.get('/api/cart', authenticateToken, (req, res) => {
  const userCart = carts.filter(cart => cart.userId === req.user.userId);
  res.json(userCart);
});

app.post('/api/cart', authenticateToken, (req, res) => {
  const { productId, quantity } = req.body;
  const product = products.find(p => p.id === productId);

  if (!product) {
    return res.status(404).json({ error: 'Product not found' });
  }

  const existingCartItem = carts.find(
    cart => cart.userId === req.user.userId && cart.productId === productId
  );

  if (existingCartItem) {
    existingCartItem.quantity += quantity;
  } else {
    carts.push({
      id: Date.now().toString(),
      userId: req.user.userId,
      productId,
      quantity,
      addedAt: new Date().toISOString()
    });
  }

  res.json({ message: 'Product added to cart successfully' });
});

app.delete('/api/cart/:productId', authenticateToken, (req, res) => {
  const productId = req.params.productId;
  const initialLength = carts.length;
  
  carts = carts.filter(
    cart => !(cart.userId === req.user.userId && cart.productId === productId)
  );

  if (carts.length === initialLength) {
    return res.status(404).json({ error: 'Cart item not found' });
  }

  res.json({ message: 'Product removed from cart successfully' });
});

// Order Routes
app.post('/api/orders', authenticateToken, (req, res) => {
  const { items, total } = req.body;

  // Generate random order statuses for demo
  const statuses = ['pending', 'confirmed', 'shipped', 'delivered'];
  const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];

  const order = {
    id: Date.now().toString(),
    userId: req.user.userId,
    items,
    total,
    status: randomStatus,
    createdAt: new Date().toISOString()
  };

  orders.push(order);

  // Clear user's cart after order
  carts = carts.filter(cart => cart.userId !== req.user.userId);

  res.status(201).json({
    message: 'Order created successfully',
    order
  });
});

app.get('/api/orders', authenticateToken, (req, res) => {
  const userOrders = orders.filter(order => order.userId === req.user.userId);
  res.json(userOrders);
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'Server is running successfully!' });
});

app.listen(PORT, () => {
  console.log(`🚀 Flipkart Backend Server running on http://localhost:${PORT}`);
  console.log(`📡 API endpoints available at http://localhost:${PORT}/api`);
});