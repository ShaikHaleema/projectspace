const API_BASE_URL = 'http://localhost:3001/api';

async function apiRequest(endpoint: string, options: RequestInit = {}) {
  const token = localStorage.getItem('token');
  const headers = {
    'Content-Type': 'application/json',
    ...(token && { Authorization: `Bearer ${token}` }),
    ...options.headers,
  };

  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...options,
    headers,
  });

  if (!response.ok) {
    throw new Error(`API Error: ${response.statusText}`);
  }

  return response.json();
}

export const api = {
  // Products
  getProducts: () => apiRequest('/products'),
  getProduct: (id: string) => apiRequest(`/products/${id}`),
  searchProducts: (query: string) => apiRequest(`/products/search?q=${query}`),
  getProductsByCategory: (category: string) => apiRequest(`/products/category/${category}`),

  // Auth
  login: (email: string, password: string) =>
    apiRequest('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),
  register: (name: string, email: string, password: string) =>
    apiRequest('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ name, email, password }),
    }),
  getProfile: () => apiRequest('/auth/profile'),

  // Cart
  getCart: () => apiRequest('/cart'),
  addToCart: (productId: string, quantity: number) =>
    apiRequest('/cart', {
      method: 'POST',
      body: JSON.stringify({ productId, quantity }),
    }),
  removeFromCart: (productId: string) =>
    apiRequest(`/cart/${productId}`, { method: 'DELETE' }),

  // Orders
  createOrder: (items: any[], total: number) =>
    apiRequest('/orders', {
      method: 'POST',
      body: JSON.stringify({ items, total }),
    }),
  getOrders: () => apiRequest('/orders'),
};